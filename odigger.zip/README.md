# affiliate-offer-scrape
Scrape affiliate offers from Odigger, Offervault and Affplus.

## comm.config
`sqlconn = 'mysql+pymysql://[username]:[password]@localhost:3306/[db_name]?charset=utf8mb4'`

## offervault_v2.py
`python offervault_v2.py [argv]`

argv: [1,69] 整数

## affpay.py
`python affpay.py [argv]`

argv: [0,76] 整数